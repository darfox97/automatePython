def init(db, api, **_):
    print(f"Soy modulo dos: {db} {api}")
