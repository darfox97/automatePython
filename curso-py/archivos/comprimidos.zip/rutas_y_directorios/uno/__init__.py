def init(graphql, **_):
    print(f"Soy modulo uno: {graphql}")
