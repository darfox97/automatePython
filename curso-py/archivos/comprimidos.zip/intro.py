print("Hola Mundo")
print("Texto repetido " * 4)

chanchito = "feliz"
