mascotas = ["Boby", "Thor", "Sira", "Akira", "Isis"]
for mascota in enumerate(mascotas):
    print(mascota)
    # print(mascota[0])
    # print(mascota[1])
