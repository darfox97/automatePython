numeros = list(range(21))
# Printea de dos en dos desde 0
print(numeros[::2])
# Printea de dos en dos desde 1
print(numeros[1::2])
# Printea de tres en tres hasta 10:
print(numeros[:10:3])
